# Saswat-Store-Annual-Sales-Analysis
Annual Sales Report Preparation and Analysis with live Dashboard using Advanced MS-Excel

Saswat Stores is a garment-selling retail outlet that wants to create an Annual Sales Report for the year 2022. The report should help Saswat understand their customer base and grow their sales through the analysis and insights generated; in the year 2023.
# Flow incorporated while doing the project:
1. Overviewing Of Data
2. Data Cleaning
3. Data Processing
4. Dashboard Creation
5. Write-up preparation based on insights and findings generated through the visualization for presenting to the client.
* Advanced MS Excel is used including Pivot Tables for the preparation of the Live Dashboard.
